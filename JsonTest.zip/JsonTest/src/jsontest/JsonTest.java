/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsontest;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Yamamoto
 */
public class JsonTest {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    String data = readFile();
    JSONArray JArray = new JSONArray(data);
    
    for(int n=0; n<JArray.length(); n++) {

            JSONObject Jobject = JArray.getJSONObject(n);

            String firstname = (String)Jobject.getJSONObject("person").get("firstName");
            String lastname = (String)Jobject.getJSONObject("person").get("lastName");
            //String address = (String)Jobject.get("address");

            //sub.add(new Subject(name , day, period));
            System.out.println(firstname + " " + lastname );
        }
    
    
  }

  private static String readFile(){
        try{
            File file = new File("/Users/Yamamoto/Desktop/test.json");
            BufferedReader br = new BufferedReader(new FileReader(file));

            String data = "";
            String str = br.readLine();
            while(str != null){
                data += str;
                str = br.readLine();
            }

            br.close();
            return data;
        }catch(FileNotFoundException e){
            System.out.println(e);
            return null;
        }catch(IOException e){
            System.out.println(e);
            return null;
        }
    }
}
